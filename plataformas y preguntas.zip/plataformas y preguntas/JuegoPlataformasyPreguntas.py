import pygame
import constants
import levels
import sys
from player import Player
from player1 import Player1
import tkinter as tk

from tkinter import ttk
import random
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 432

Clock  = pygame.time.Clock()
color_rojo  = (255,0,0)
ANCHO = 800
ALTO = 600
NEGRO = (0, 0, 0)
green = (0, 255, 0)
blue =  (0, 0, 128)

cerebro_size = 50
cerebro_pos = [ANCHO / 2 ,350]
game_over = False
clock = pygame.time.Clock()


def main():
    #destruye el tk inter anterior


    #Inicia el programa
    pygame.init()
    # Es la altura y lo gordo de la pantalla
    size = [800, 432]
    screen = pygame.display.set_mode(size)
    pygame.display.set_caption("Plataformas y preguntas ")
    ground_image = pygame.image.load("ground.png").convert_alpha()
    ground_width = ground_image.get_width()
    ground_height = ground_image.get_height()

    # crea al jugador
    player = Player()


    # Crea la nube
    nube_size = 50
    nube_pos = [random.randint(0, ANCHO - nube_size),0]
    nube = pygame.image.load("nube1.png").convert()
    nube.set_colorkey([0, 0, 0])

    # Crea la idea
    idea_size = 50
    idea_pos = [random.randint(0, 800 - idea_size),0]
    idea = pygame.image.load("ideas2.png").convert()
    idea.set_colorkey([0, 0, 0])

    # Crea la idea
    cerebro_size = 200
    cerebro_pos = [ANCHO / 2 ,350]
    cerebro = pygame.image.load("cerebro1.png").convert()
    cerebro.set_colorkey([0, 0, 0])

    # Crea los niveles
    level_list = []
    level_list.append(levels.Level_01(player))

    bg_images = []
    for i in range(1, 6):
        bg_image = pygame.image.load(f"plx-{i}.png").convert_alpha()
        bg_images.append(bg_image)
        bg_width = bg_images[0].get_width()
    scroll = 0

    def draw_ground():
        for x in range(100):
            screen.blit(ground_image, ((x * ground_width) - scroll * 2.5, SCREEN_HEIGHT - ground_height))    

    def draw_bg():
        for x in range(100):
            speed = 0.35
            for i in bg_images:
                speed += 0.2
                screen.blit(i, ((x * bg_width) - scroll * speed, 0))

    def detectar_colision(cerebro,idea_pos):
        jx = cerebro[0]
        jy = cerebro[1]
        ex = idea_pos[0]
        ey = idea_pos[1]
        if (ex >= jx and ex <(jx + cerebro_size)) or (jx >= ex and jx < (ex + idea_size)):
            if (ey >= jy and ey <(jy + cerebro_size)) or (jy >= ey and jy < (ey + idea_size)):
                return True
        return False

    level_list.append(levels.Level_02(player))


    # Establece el nivel actual
    current_level_no = 0
    current_level = level_list[current_level_no]

    active_sprite_list = pygame.sprite.Group()
    player.level = current_level
    
    player.rect.x = 340
    player.rect.y = constants.SCREEN_HEIGHT - player.rect.height
    active_sprite_list.add(player)
    X = 400
    Y = 400

    font = pygame.font.Font('freesansbold.ttf', 20)
    text = font.render ('El método científico es una metodología', True, green,NEGRO)
    text1 = font.render('El método científico es una metodología', True, green,NEGRO)
    textRect1 = text1.get_rect()
    textRect = text.get_rect()
    textRect.center = (200, Y // 2.40)
    textRect1.center = (200, Y // 2.15)

    font = pygame.font.Font('freesansbold.ttf', 20)
    text2 = font.render ('nose nose nose nose nose nose nose nose', True, green,NEGRO)
    text3 = font.render ('nose nose nose nose nose nose nose nose', True, green,NEGRO)
    textRect3 = text3.get_rect()
    textRect2 = text2.get_rect()
    textRect2.center = (200, Y // 2.40)
    textRect3.center = (200, Y // 2.15)

    font = pygame.font.Font('freesansbold.ttf', 20)
    text4 = font.render ('bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb', True, green,NEGRO)
    text5 = font.render ('bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb', True, green,NEGRO)
    textRect5 = text5.get_rect()
    textRect4 = text4.get_rect()
    textRect4.center = (200, Y // 2.40)
    textRect5.center = (200, Y // 2.15)





    #Se Reiniciara loop Hasta que el usuario le de a cerrar
    done = False
    # Se usa para administrar qué tan rápido se actualiza la pantalla
    clock = pygame.time.Clock()

    # -------- Bucle de programa principal -----------
    while not done:
        for event in pygame.event.get(): # El usuario hizo algo
            if event.type == pygame.QUIT: # Si el usuario hizo clic en cerrar
                done = True # Marcar que hemos terminado, así que salimos de este ciclo
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    player.go_left()
                if event.key == pygame.K_RIGHT:
                    player.go_right()
                if event.key == pygame.K_UP:
                    player.jump()
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT and player.change_x < 0:
                    player.stop()
                if event.key == pygame.K_RIGHT and player.change_x > 0:
                    player.stop()



           # done = True

        Clock.tick(60)
        draw_bg()
        draw_ground()

        #Funcion del fondo (Back ground)
        key = pygame.key.get_pressed()
        if key[pygame.K_LEFT] and scroll > 0:
                scroll -= 5
        if key[pygame.K_RIGHT] and scroll < 3000:
                scroll += 5

        #Posicion y dibujo de la nube
        screen.blit(nube, [nube_pos[1], nube_pos[0]])
        if nube_pos[1] >= 0 and nube_pos[1] < 1200:
            nube_pos[1] += 20
        else:
            nube_pos[0] = random.randint(0,100 - nube_size)
            nube_pos[1] = 0

        #Posicion y dibujo de las ideas
        screen.blit(idea, [idea_pos[0], idea_pos[1]])
        if idea_pos[1] >= 0 and idea_pos[1] < ALTO:
            idea_pos[1] += 20
        else:
            idea_pos[0] = random.randint(0,ANCHO - idea_size)
            idea_pos[1] = 0

        #Dibujar Jugador
        screen.blit(cerebro, [cerebro_pos[0], cerebro_pos[1]])

        #Colisiones Entre las ideas y el cerebro
        CPU = random.randint(1, 3)
        if detectar_colision(cerebro_pos,idea_pos):
            if CPU == 1:
                screen.blit(text, textRect)
                screen.blit(text1, textRect1)
            if CPU == 2:
                screen.blit(text2, textRect2)
                screen.blit(text3, textRect3)
            else:
                screen.blit(text4, textRect4)
                screen.blit(text5, textRect5)
        # Dibujar Enemigo
        active_sprite_list.update() # Actualizar el jugador.

        current_level.update() # Actualizar elementos en el nivel

        # Si el jugador se acerca al lado derecho, cambia el mundo a la izquierda (-x)
        if player.rect.right >= 500:
            diff = player.rect.right - 500
            player.rect.right = 500
            current_level.shift_world(-diff)

        # Si el jugador se acerca al lado izquierdo, cambia el mundo a la derecha (+x)
        if player.rect.left <= 120:
            diff = 120 - player.rect.left
            player.rect.left = 120
            current_level.shift_world(diff)


        # Si el jugador llega al final del nivel, pasa al siguiente nivel    
        current_position = player.rect.x + current_level.world_shift
        if current_position < current_level.level_limit:
            player.rect.x = 120
            if current_level_no < len(level_list)-1:
                current_level_no += 1
                current_level = level_list[current_level_no]
                player.level = current_level
        # TODO EL CÓDIGO PARA DIBUJAR DEBE ESTAR DEBAJO DE ESTE COMENTARIO
        current_level.draw(screen)
        active_sprite_list.draw(screen)

        # Limite a 60 cuadros por segundo
        clock.tick(60)

        # Continúe y actualice la pantalla con lo que hemos dibujado.
        pygame.display.flip()

    # Sea amigable con IDLE. Si olvida esta línea, el programa se 'colgará'
    # al salir.
    pygame.quit()

def main2():
    #destruye el tk inter anterior


    #Inicia el programa
    pygame.init()
    # Es la altura y lo gordo de la pantalla
    size = [800, 432]
    screen = pygame.display.set_mode(size)
    pygame.display.set_caption("Plataformas y preguntas ")
    ground_image = pygame.image.load("ground.png").convert_alpha()
    ground_width = ground_image.get_width()
    ground_height = ground_image.get_height()

    # crea al jugador
    player = Player1()


    # Crea la nube
    nube_size = 50
    nube_pos = [random.randint(0, ANCHO - nube_size),0]
    nube = pygame.image.load("nube1.png").convert()
    nube.set_colorkey([0, 0, 0])

    # Crea la idea
    idea_size = 50
    idea_pos = [random.randint(0, 800 - idea_size),0]
    idea = pygame.image.load("ideas2.png").convert()
    idea.set_colorkey([0, 0, 0])

    # Crea la idea
    cerebro_size = 50
    cerebro_pos = [ANCHO / 2 ,350]
    cerebro = pygame.image.load("cerebro1.png").convert()
    cerebro.set_colorkey([0, 0, 0])

    # Crea los niveles
    level_list = []
    level_list.append(levels.Level_01(player))

    bg_images = []
    for i in range(1, 6):
        bg_image = pygame.image.load(f"plx-{i}.png").convert_alpha()
        bg_images.append(bg_image)
        bg_width = bg_images[0].get_width()
    scroll = 0

    def draw_ground():
        for x in range(100):
            screen.blit(ground_image, ((x * ground_width) - scroll * 2.5, SCREEN_HEIGHT - ground_height))    

    def draw_bg():
        for x in range(100):
            speed = 0.35
            for i in bg_images:
                speed += 0.2
                screen.blit(i, ((x * bg_width) - scroll * speed, 0))

    def detectar_colision(cerebro,idea_pos):
        jx = cerebro[0]
        jy = cerebro[1]
        ex = idea_pos[0]
        ey = idea_pos[1]
        if (ex >= jx and ex <(jx + cerebro_size)) or (jx >= ex and jx < (ex + idea_size)):
            if (ey >= jy and ey <(jy + cerebro_size)) or (jy >= ey and jy < (ey + idea_size)):
                return True
        return False

    level_list.append(levels.Level_02(player))


    # Establece el nivel actual
    current_level_no = 0
    current_level = level_list[current_level_no]

    active_sprite_list = pygame.sprite.Group()
    player.level = current_level
    
    player.rect.x = 340
    player.rect.y = constants.SCREEN_HEIGHT - player.rect.height
    active_sprite_list.add(player)
    X = 400
    Y = 400

    font = pygame.font.Font('freesansbold.ttf', 32)
    text = font.render ('El método científico es una metodología', True, green, blue)
    text1 = font.render('El método científico es una metodología', True, green, blue)
    textRect1 = text1.get_rect()
    textRect = text.get_rect()
    textRect.center = (315, Y // 2.40)
    textRect1.center = (315, Y // 2)
    #Se Reiniciara loop Hasta que el usuario le de a cerrar
    done = False
    # Se usa para administrar qué tan rápido se actualiza la pantalla
    clock = pygame.time.Clock()

    # -------- Bucle de programa principal -----------
    while not done:
        for event in pygame.event.get(): # El usuario hizo algo
            if event.type == pygame.QUIT: # Si el usuario hizo clic en cerrar
                done = True # Marcar que hemos terminado, así que salimos de este ciclo
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    player.go_left()
                if event.key == pygame.K_RIGHT:
                    player.go_right()
                if event.key == pygame.K_UP:
                    player.jump()

           # done = True

        Clock.tick(60)
        draw_bg()
        draw_ground()

        #Funcion del fondo (Back ground)
        key = pygame.key.get_pressed()
        if key[pygame.K_LEFT] and scroll > 0:
                scroll -= 5
        if key[pygame.K_RIGHT] and scroll < 3000:
                scroll += 5

        #Posicion y dibujo de la nube
        screen.blit(nube, [nube_pos[1], nube_pos[0]])
        if nube_pos[1] >= 0 and nube_pos[1] < 1200:
            nube_pos[1] += 20
        else:
            nube_pos[0] = random.randint(0,100 - nube_size)
            nube_pos[1] = 0

        #Posicion y dibujo de las ideas
        screen.blit(idea, [idea_pos[0], idea_pos[1]])
        if idea_pos[1] >= 0 and idea_pos[1] < ALTO:
            idea_pos[1] += 20
        else:
            idea_pos[0] = random.randint(0,ANCHO - idea_size)
            idea_pos[1] = 0

        #Dibujar Jugador
        screen.blit(cerebro, [cerebro_pos[0], cerebro_pos[1]])


        #Colisiones Entre las ideas y el cerebro
        if detectar_colision(cerebro_pos,idea_pos):
            screen.blit(text, textRect)
            screen.blit(text1, textRect1)
        # Dibujar Enemigo
        active_sprite_list.update() # Actualizar el jugador.

        current_level.update() # Actualizar elementos en el nivel

        # Si el jugador se acerca al lado derecho, cambia el mundo a la izquierda (-x)
        if player.rect.right >= 500:
            diff = player.rect.right - 500
            player.rect.right = 500
            current_level.shift_world(-diff)

        # Si el jugador se acerca al lado izquierdo, cambia el mundo a la derecha (+x)
        if player.rect.left <= 120:
            diff = 120 - player.rect.left
            player.rect.left = 120
            current_level.shift_world(diff)


        # Si el jugador llega al final del nivel, pasa al siguiente nivel    
        current_position = player.rect.x + current_level.world_shift
        if current_position < current_level.level_limit:
            player.rect.x = 120
            if current_level_no < len(level_list)-1:
                current_level_no += 1
                current_level = level_list[current_level_no]
                player.level = current_level
        # TODO EL CÓDIGO PARA DIBUJAR DEBE ESTAR DEBAJO DE ESTE COMENTARIO
        current_level.draw(screen)
        active_sprite_list.draw(screen)

        # Limite a 60 cuadros por segundo
        clock.tick(60)

        # Continúe y actualice la pantalla con lo que hemos dibujado.
        pygame.display.flip()

    # Sea amigable con IDLE. Si olvida esta línea, el programa se 'colgará'
    # al salir.
    pygame.quit()
 
#Tk inter Primera Pantalla
import time
from tkinter import *
from tkinter import ttk
tk = Tk()

def cosa():
    tk.destroy()
    root1 = Tk()
    pygame.mixer.music.pause()
    pygame.mixer.music.load("rolita2.mp3")
    pygame.mixer.music.play(-1)

    root1.config(width=800, height=800)
    root1.title("Jugadores")
    image = PhotoImage(file="plx-1.png")

    label = ttk.Label(image=image)
    label.pack()

    boton = ttk.Button(text="Normal",command=main)
    boton.place(x=50, y=50)

    boton = ttk.Button(text="Geometry Mode", command=main2)
    boton.place(x=50, y=100)
    root1.mainloop()
    
    
pygame.mixer.init()
pygame.mixer.music.load("rolita1.mp3")
pygame.mixer.music.play(-1)

tk.title("Juego")
tk.geometry("1500x1500") 
imagen = PhotoImage(file="baas.png")
fondo = Label(tk, image = imagen).place(x = 0,y= 0, width="2000", height="2000")

canvas = Canvas(tk, width = 2000, height = 2000)

image2 = PhotoImage(file="baas.png")
canvas.create_image(500,150,image=image2)
canvas.pack()

for x in range(0,60):
        canvas.move(1,0,6.5)
        tk.update()
        time.sleep(0.055)

image3 = PhotoImage(file="Titulo1.png")
canvas.create_image(700,200,image=image3)
canvas.pack()

image4 = PhotoImage(file="copyrights.png")
canvas.create_image(1000,450,image=image4)
canvas.pack()


boton = Button(tk, text="Jugar",width = 20, bg= "deepskyblue2", height = 2, command=cosa)
boton.place(x=650, y=350)

boton1 = Button(tk, text="salir",width = 20, bg= "deepskyblue2", height = 2, command=quit)
boton1.place(x=(650), y=400)

def quit(self):
    self.tk.destroy()

tk.mainloop()
